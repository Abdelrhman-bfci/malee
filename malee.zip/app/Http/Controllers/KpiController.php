<?php

namespace App\Http\Controllers;

use App\Player;
use App\PlayerKpis;
use Illuminate\Http\Request;

class KpiController extends Controller
{
    public function index(Request $request , $player_id){

        $player = Player::where('PK_Player', $player_id)->first();
        if ($player){
            if ($player->items){

                $needItemsCount = $player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')->limit(5)->where('itemtype.IsImportant', 1)->count();
                ($needItemsCount > 3)? $kpi1 = 1 : $kpi1 = 0;
                ($needItemsCount > 4)? $kpi3 = 1 : $kpi3 = 0;

                /////
                $totalNeedItems = [];
                foreach ($player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')
                             ->where('itemtype.IsImportant', 1)->get() as $item){
                    array_push($totalNeedItems , $item->pivot->ItemDisplayedPrice);
                }

                $totalWantItems = [];
                foreach ($player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')
                             ->where('itemtype.IsImportant', 0)->get() as $item){
                    array_push($totalWantItems , $item->pivot->ItemDisplayedPrice);
                }

                $kpi4 = (array_sum($totalWantItems)/ array_sum($totalNeedItems))*100;

                ////
                $cond1 = ($player->CharityPoints / $player->Income)*100;
                $cond2 = ($player->DsiplayedPrice / $player->Income)*100;
                $cond3 = ($player->Money / $player->Income)*100;
                (($cond1 >= 60  && $cond1 <= 80) || ($cond2 > 10 && $cond2 <= 40) ||  ($cond3 > 10 && $cond3<= 40)) ? $kpi5 = 1 :  $kpi5 = 0;

                ///

                ($player->InvestmentReturn > 0) ? $kpi9 = 1 : $kpi9 = 0;
                ($player->items->count() > 8 && ($cond3 >= 5 && $cond3 < 20 )) ? $kpi12 = 1 : $kpi12 = 0;
                ($player->items->count() >= 7 && ($cond1 >= 8 && $cond1 < 15 )) ? $kpi18 = 1 : $kpi18 = 0;

                $playerKPi = PlayerKpis::where('FK_player_id', $player->PK_Player)->first();
                if ($playerKPi){
                    $playerKPi->update(
                        ['FK_player_id' => $player->PK_Player ,
                            'kpi1' => $kpi1 ,
                            'kpi3' => $kpi3 ,
                            'kpi4' =>$kpi4 ,
                            'kpi5' =>$kpi5 ,
                            'kpi9' =>$kpi9,
                            'kpi12' =>$kpi12,
                            'kpi18' =>$kpi18,
                        ]);
                }else{
                    $playerKPi =  PlayerKpis::create(
                        ['FK_player_id' => $player->PK_Player ,
                            'kpi1' => $kpi1 ,
                            'kpi3' => $kpi3 ,
                            'kpi4' =>$kpi4  ,
                            'kpi5' =>$kpi5 ,
                            'kpi9' =>$kpi9 ,
                            'kpi12' =>$kpi12 ,
                            'kpi18' =>$kpi18,
                        ]);
                }

                return response($playerKPi);
            }
        }

    }

    public  function  Resolve($player_id){
        $player = Player::where('PK_Player', $player_id)->first();
        if ($player){
            if ($player->items){

                $needItemsCount = $player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')->limit(5)->where('itemtype.IsImportant', 1)->count();
                ($needItemsCount > 3)? $kpi1 = 1 : $kpi1 = 0;
                ($needItemsCount > 4)? $kpi3 = 1 : $kpi3 = 0;

                /////
                $totalNeedItems = [];
                foreach ($player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')
                             ->where('itemtype.IsImportant', 1)->get() as $item){
                    array_push($totalNeedItems , $item->pivot->ItemDisplayedPrice);
                }

                $totalWantItems = [];
                foreach ($player->items()->leftJoin('itemtype', 'itemtype.PK_ItemType','=','item.FK_ItemType')
                             ->where('itemtype.IsImportant', 0)->get() as $item){
                    array_push($totalWantItems , $item->pivot->ItemDisplayedPrice);
                }

                $kpi4 =  array_sum($totalNeedItems) > 0 ? (array_sum($totalWantItems)/ array_sum($totalNeedItems))*100 : 0;

                ////
                $cond1 = $player->Income > 0 ? ($player->CharityPoints / $player->Income)*100 : 0;
                $cond2 = $player->Income > 0 ? ($player->DsiplayedPrice / $player->Income)*100 : 0;
                $cond3 = $player->Income > 0 ? ($player->Money / $player->Income)*100 : 0;
                (($cond1 >= 60  && $cond1 <= 80) || ($cond2 > 10 && $cond2 <= 40) ||  ($cond3 > 10 && $cond3<= 40)) ? $kpi5 = 1 :  $kpi5 = 0;

                ///

                ($player->InvestmentReturn > 0) ? $kpi9 = 1 : $kpi9 = 0;
                ($player->items->count() > 8 && ($cond3 >= 5 && $cond3 < 20 )) ? $kpi12 = 1 : $kpi12 = 0;
                ($player->items->count() >= 7 && ($cond1 >= 8 && $cond1 < 15 )) ? $kpi18 = 1 : $kpi18 = 0;

                $playerKPi = PlayerKpis::where('FK_player_id', $player->PK_Player)->first();
                if ($playerKPi){
                    $playerKPi->update(
                        ['FK_player_id' => $player->PK_Player ,
                            'kpi1' => $kpi1 ,
                            'kpi3' => $kpi3 ,
                            'kpi4' =>$kpi4 ,
                            'kpi5' =>$kpi5 ,
                            'kpi9' =>$kpi9,
                            'kpi12' =>$kpi12,
                            'kpi18' =>$kpi18,
                        ]);
                }else{
                    $playerKPi =  PlayerKpis::create(
                        ['FK_player_id' => $player->PK_Player ,
                            'kpi1' => $kpi1 ,
                            'kpi3' => $kpi3 ,
                            'kpi4' =>$kpi4  ,
                            'kpi5' =>$kpi5 ,
                            'kpi9' =>$kpi9 ,
                            'kpi12' =>$kpi12 ,
                            'kpi18' =>$kpi18,
                        ]);
                }

                return response($playerKPi);
            }
        }
    }
}
